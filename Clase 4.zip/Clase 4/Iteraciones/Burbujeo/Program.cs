﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Burbujeo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numero = new int [10];
            int aux;
            for (int i =0; i<numero.Length; i++)
            {
                for(int j= 0; j<numero.Length - 1; i++)
                {
                    if(numero[j]<numero[j+1])
                    {
                        aux = numero[j];
                        numero[j] = numero[j + 1];
                        numero[j + 1] = aux;
                    }
                }
            }


        }
    }
}
