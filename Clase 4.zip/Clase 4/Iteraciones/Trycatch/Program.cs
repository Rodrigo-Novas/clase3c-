﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trycatch
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] facturacionPorMes = new int[6];
            string[] nombreMeses = new string[6] { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio" };
            for(int mes = 1; mes<=6; mes++)
            {
                Console.WriteLine("Ingrese facturacion de {0}", nombreMeses[mes-1]);
                int facturacion = Int32.Parse(Console.ReadLine());
                facturacionPorMes[mes - 1]= facturacion;
            }

            for (int i =0; i <facturacionPorMes.Length; i++)
            {
                Console.WriteLine("La facturacion del mes {0}, es: {1}", nombreMeses[i], facturacionPorMes[i]);

            }
            Console.ReadKey();
        }
    }
}
