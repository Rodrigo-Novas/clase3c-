﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iteraciones
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 2;
            //if (num%2!=0) sacas el resto del numero dividido dos y si el resto es distinto a cero significa que es impar
            //if (num&1==1) el ampersand 1 saca la primer linea del binario osea 010101 y verifica que si es 1 entonces el numero es impar
            Console.WriteLine("Hola jorge");
            //operador ternario = (CONDICION)? TRUE : FALSE
            //Ejemplo:

            Console.WriteLine((num % 2 == 0) ? "Par" : "Impar"); //remplazaria if else
            Console.ReadKey();

        }
    }
}
