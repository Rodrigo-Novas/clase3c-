﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iteraciones2
{
    class Program
    {
        static void Main(string[] args)
        {
            int contador=1;
            int contador2 = 1;
            int contador3 = 10;
            int contador4 = 10;
            int contador5 = 1;
            int contador6 = 1;
            int sum = 0;
            while (contador<=10)
            {
                Console.WriteLine(contador);
                contador++;
            }
            Console.Write("\nIncremento x2");

            while(contador2<=10)
            { 
                Console.WriteLine(contador2);
                contador2 += 2;
            }
            Console.Write("\nDecremento");

            while (contador3 >= 1)
            {
                Console.WriteLine(contador3);
                contador3 --;
            }


            while (contador4 >= 1)
            {
                if (contador4 != 2 && contador4 != 5 && contador4 != 9)
                {
                    Console.WriteLine(contador4);
                }
                contador4--;
            }

            Console.Write("\nDecremento");



            while (contador5 <= 30)
            {

                if (contador5 < 10 || contador5 > 20)
                {
                    Console.WriteLine(contador5);

                }

                contador5++;
            }


            while (contador6<=25)
            {
                if(contador6%2==0)
                {
                    sum = sum + contador6;
                }

                contador6++;
            }


            for(int i =0; i<5; i++)
            {
                Console.WriteLine((i % 2 == 0) ? "@@" : "@");
            }

            Console.WriteLine();

            for (int i = 1; i < 6; i++)
            {
                for (int j = 6; j > i; j--)
                {
                    Console.WriteLine("@");
                }
            }

            Console.WriteLine("\n La suma de los numeros pares del 1 al 25 es {0}", sum);

            Console.ReadKey();
        }
    }
}
