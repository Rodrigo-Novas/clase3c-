﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

struct eEstructura
{
    public int jose;
    public int roberto;
}
namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //array conjunto de elementos bajo un mismo nombre, se accede por index
            //Se puede hardcodear int[]numeros = new int[10] {1,2,3,4,5...} tambien si lo creas vacio new int[] = {1,2,3,4} es dinamico y lo podes redimensionar
            //Se puede hacer un array multidimensional con new int [2,5]

            // eEstructura empleado = new eEstructura(); //estructura
            int[] numeros = new int [10];
            int maximo = numeros[0];
            int minimo = numeros[0];
            int posMinimo = 0;
            int posMaximo = 0;

            Console.WriteLine("Ingrese 10 numeros");
            for (int i = 0; i < numeros.Length; i++)
            {
               numeros[i] = int.Parse(Console.ReadLine()); //pide los datos por pantalla
            }


            for (int i=0; i<numeros.Length; i++)
            {
                if (numeros[i] > maximo)
                {
                    maximo = numeros[i];
                    posMaximo = i;
                }
                if (numeros[i] < minimo)
                {
                    minimo = numeros[i];
                    posMinimo = i;
                }
            }
            Console.WriteLine("El minimo es {0} y su posicion es {1}, el maximo es {2} y su posicion es {3}", minimo, posMinimo, minimo, posMaximo);
           


            Console.ReadKey();  
         
        }
    }
}
